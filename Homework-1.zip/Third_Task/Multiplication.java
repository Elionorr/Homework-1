package Third_Task;

public class Multiplication{  
    public static void main(String[] args) {           
        String str1 = args[0];
		Integer x = Integer.valueOf(str1);
       	String str2 = args[1];
		Integer y = Integer.valueOf(str2);
		Integer z = x*y;
     
		  System.out.println(x);  
		  System.out.println(y); 
		  System.out.println(z);
    }  
}  