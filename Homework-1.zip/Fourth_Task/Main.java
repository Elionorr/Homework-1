package Fourth_Task;

public class Main{
	public static void main(String[] args){
		int x = 4;
		int y = 5;
		int z;
		
		System.out.println("Fisrt Number: " + x);
		System.out.println("Second Number: " + y);
		
		z=x;
		x=y;
		y=z;
		
		System.out.println("After changing, first number is " + x + " and second number is " + y);
	}
}