package Fifth_Task;

public class Main{
	public static void main(String[] args){
		int x = Integer.parseInt(args[0]);
        int y = Integer.parseInt(args[1]);
        int z = Integer.parseInt(args[2]);
		
		System.out.println("Total number of arguments is: " + args.length);
	}
}